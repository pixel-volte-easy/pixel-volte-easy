#!/system/bin/sh

# If there is no backup stock boot.img then do manual backup
STOCK_BOOT_BAK_DIR=`ls -rt /data | grep "magisk_backup_" | tail -1`
if [ "$STOCK_BOOT_BAK_DIR" ]
then
	if [ ! -e "$STOCK_BOOT_BAK_DIR/boot.img.gz" ]
	then
		cp /sdcard/Download/boot.img /data/$STOCK_BOOT_BAK_DIR/
		gzip -9f /data/$STOCK_BOOT_BAK_DIR/boot.img
	fi
else
	if [ -e "/sdcard/Download/boot.img" ]
	then
		SHA_STR=`sha1sum -b /sdcard/Download/boot.img`
		mkdir /data/magisk_backup_$SHA_STR
		cp /sdcard/Download/boot.img /data/magisk_backup_$SHA_STR/
		gzip -9f /data/magisk_backup_$SHA_STR/boot.img
		chmod -R 755 /data/magisk_backup_$SHA_STR
	fi
fi
