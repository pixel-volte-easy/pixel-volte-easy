#!/system/bin/sh

ACTION="$1"
BUILD="$2"
MODEL="$3"

CURL_RES="/data/local/tmp/volte_easy_temp/tmp_curl_result"

if [ "$ACTION" == "getdate" ]
then
	date +%Y%m%d
elif [ "$ACTION" == "getver" ]
then
	getprop ro.build.version.release
elif [ "$ACTION" == "getprovision" ]
then
	getprop persist.dbg.volte_avail_ovr
elif [ "$ACTION" == "getcustomversion" ]
then
	getprop | grep "org.*.version.display" | awk '{ print $2 }' | sed "s/\[//; s/\]//"
elif [ "$ACTION" == "getmodel" ]
then
	getprop ro.product.name
elif [ "$ACTION" == "getbuild" ]
then
	getprop ro.build.id | tr '[A-Z]' '[a-z]'
elif [ "$ACTION" == "getbootloaderstat" ]
then
	getprop ro.boot.flash.locked
elif [ "$ACTION" == "getmagiskver" ]
then
	magisk -v | sed 's/:MAGISK.*//'
elif [ "$ACTION" == "getdsds" ]
then
	getprop persist.radio.multisim.config
elif [ "$ACTION" == "getcarrier" ]
then
	getprop gsm.sim.operator.alpha
elif [ "$ACTION" == "getcarriers" ]
then
	getprop gsm.sim.operator.alpha | sed -n "s/\(.*\),\(.*\)/\1\ \2/p"
elif [ "$ACTION" == "getbootimg" ]
then
	cat $CURL_RES | sed -n "s/.*\">\(.*$BUILD\-boot\.img\.zip\).*/\1/p"
elif [ "$ACTION" == "getfactory" ]
then
	cat $CURL_RES | sed -n "s/.*href=.\(.*\/\(.*$MODEL\-$BUILD.*\.zip\)\)..*/\1\ \2/p"
elif [ "$ACTION" == "getupdate" ]
then
	cat $CURL_RES | grep "\.zip" | grep "$MODEL" | grep "\-ota\-$BUILD" | sed "s/.*href=.\(.*\/\(.*\.zip\)\).*/\1\ \2/"
elif [ "$ACTION" == "getlatestbuild" ]
then
	OPTION="$2"
	MODEL="$3"
	PARAM="$4"
	if [ "$OPTION" == "prepared" ]
	then
		echo "$PARAM" | sed -n "s/.*$MODEL\-\(.*\)\-factory\-.*/\1/p"
	elif [ "$OPTION" == "car_all" ]
	then
		cat $CURL_RES | grep "\.checked" | egrep -i ".*$MODEL\-([A-Za-z0-9\.]*)(\-All.*)*\.checked" | sed -n "s/.*$MODEL\-\([A-Za-z0-9\.]*\)\(\-.*\)*\.checked.*/\1/p" | tail -1
	elif [ "$OPTION" == "car_fi" ]
	then
		cat $CURL_RES | grep "\.checked" | egrep -i ".*$MODEL\-([A-Za-z0-9\.]*)(\-(All.*)|(.*Fi[^D][^o].*)*)\.checked" | sed -n "s/.*$MODEL\-\([A-Za-z0-9\.]*\)\(\-.*\)*\.checked.*/\1/p" | tail -1
	elif [ "$OPTION" == "car_jp" ]
	then
		cat $CURL_RES | grep "\.checked" | egrep -i ".*$MODEL\-([A-Za-z0-9\.]*)(\-(All.*)|(.*JP.*)*)\.checked" | sed -n "s/.*$MODEL\-\([A-Za-z0-9\.]*\)\(\-.*\)*\.checked.*/\1/p" | tail -1
	elif [ "$OPTION" == "car_eu" ]
	then
		cat $CURL_RES | grep "\.checked" | egrep -i ".*$MODEL\-([A-Za-z0-9\.]*)(\-(All.*)|(.*E[Uurope].*)*)\.checked" | sed -n "s/.*$MODEL\-\([A-Za-z0-9\.]*\)\(\-.*\)*\.checked.*/\1/p" | tail -1
	fi
elif [ "$ACTION" == "getmagiskpkg" ]
then
	strings /data/adb/magisk.db | grep -oE requester..* | cut -c10-
elif [ "$ACTION" == "magiskcopy" ]
then
	if [ ! -e /data/adb/magisk ]
	then
		mkdir /data/adb/magisk
	fi
	cp -r /data/local/tmp/volte_easy_temp/magisk_tools/* /data/adb/magisk/
	chown -R root:root /data/adb/magisk
fi
